# Mnist-tensorFlow-AndroidDemo
## 
- 相关说明，请查看鄙人博客：https://blog.csdn.net/guyuealian/article/details/79672257
